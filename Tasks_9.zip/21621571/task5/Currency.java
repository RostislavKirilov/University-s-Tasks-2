package bg.tu_varna.sit.task5;

public enum Currency {
    BGN,
    USD,
    EUR,
    GBP    
}