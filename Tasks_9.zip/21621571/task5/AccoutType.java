package bg.tu_varna.sit.task5;

public enum AccoutType {
    PERSONAL,
    CORPORATE    
}