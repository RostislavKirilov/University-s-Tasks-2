package bg.tu_varna.sit.task5;

public class InvalidDataException extends Exception{

    public InvalidDataException() {
        super("Invalid input");
    }
    
    
}
