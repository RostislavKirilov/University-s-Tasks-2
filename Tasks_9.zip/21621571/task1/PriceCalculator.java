package bg.tu_varna.sit.task1;

public interface PriceCalculator {
    double calculateStayPrice();
    double discount();
    double calculateReservationPrice();
}