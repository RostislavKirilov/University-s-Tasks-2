package bg.tu_varna.sit.task1;

public enum Exposure {
    SEA_VIEW,
    PARK_VIEW    
}