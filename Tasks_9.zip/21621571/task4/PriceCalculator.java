package bg.tu_varna.sit.task4;

public interface PriceCalculator {
    double calculate();    
}