package bg.tu_varna.sit.task4;

public enum PropertyType {
    NEW,
    OLD    
}