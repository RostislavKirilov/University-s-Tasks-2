package bg.tu_varna.sit.task4;

public enum Exposition {
    SOUTH,
    WEST,
    EAST,
    NORTH,
    SOUTHWEST,
    SOUTHEAST,
    NORTHWEST,
    NORTHEAST    
}