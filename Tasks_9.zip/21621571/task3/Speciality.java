package bg.tu_varna.sit.task3;

public enum Speciality {
    SIT,
    CST,
    CCT,
    A    
}