package bg.tu_varna.sit.task1;

public class Medical <E>{
    private E patient;
    private Condition condition;

    public Medical(E patient, Condition condition) {
        this.patient = patient;
        this.condition = condition;
    }


    public E getPatient() {
        return patient;
    }

    public void setPatient(E patient) {
        this.patient = patient;
    }

    public Condition getCondition() {
        return condition;
    }


    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    public int calculatePotion(E patient){
        double doza = 0.0;
        if(patient.getClass().getName() == "Child"){
            doza = ((Child)patient).getWeight()*0.25;
        }else{
            doza = 25;
        }
        if(condition == Condition.DAMAGED){
            doza*=2;
        }
        return Math.round((int)doza);
    }

    public String getPrescription(){
        return "Пациент:\n" + patient.toString() + "\nДозировка: " + calculatePotion(patient) + "мл.";
    }

    public String getCoupon(){
        return "Издаден купон на: " + (patient.getClass().getName()=="Child" ? ((Child)patient).getName():((Adult)patient).getName());
    }
}
