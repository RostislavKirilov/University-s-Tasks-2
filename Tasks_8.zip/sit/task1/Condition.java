package bg.tu_varna.sit.task1;

public enum Condition {
    GOOD,
    STABLE,
    DAMAGED
}
