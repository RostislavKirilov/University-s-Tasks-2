package bg.tu_varna.sit.task1;

public class InvalidAgeException extends Exception{
    public InvalidAgeException() {
        super("Invalid age!\n");
    }
}
