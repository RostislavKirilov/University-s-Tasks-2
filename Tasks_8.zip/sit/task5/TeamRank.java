package bg.tu_varna.sit.task5;

public enum TeamRank {
    TOP_TEAM,
    AVERAGE_TEAM,
    BOTTOM_TEAM
}