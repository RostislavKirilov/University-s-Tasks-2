package bg.tu_varna.sit.task3;

public enum AgeGroup {
    CHILD,
    TEENAGE,
    ADULT,
    PENSIONER    
}