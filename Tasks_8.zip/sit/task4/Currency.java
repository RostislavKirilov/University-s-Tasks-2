package bg.tu_varna.sit.task4;

public enum Currency {
    BGN,
    USD,
    EUR    
}