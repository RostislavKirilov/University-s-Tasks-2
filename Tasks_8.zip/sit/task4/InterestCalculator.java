package bg.tu_varna.sit.task4;

public interface InterestCalculator {
        double calculateAccountInterest();
}