package com.company;

public class Main extends Section {

    public static void main(String[] args)
    {
        PaperDocument[] arr;
        arr = new PaperDocument[2];
        DiscStorage[] arr2;
        arr2 = new DiscStorage[2];

        arr[0] = new PaperDocument("T", "2022-28-11", 69, true);
        arr[1] = new PaperDocument("W", "2009-01-01", 9001, true);

        arr2[0] = new DiscStorage(00001, "The Lord of the Rings complete trilogy (pirated)");
        arr2[1] = new DiscStorage(00002, "IDK man");

        Section.findDocument1("E", arr);
        Section.findDocument2(00001, arr2);

    }
}
