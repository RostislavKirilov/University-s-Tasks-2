package com.company;

public class DiscStorage
{
    int id;
    String content;

    DiscStorage(int id, String content)
    {
        this.id = id;
        this.content = content;
    }
}
