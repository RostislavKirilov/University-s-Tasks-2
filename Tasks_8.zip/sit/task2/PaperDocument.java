package com.company;

public class PaperDocument
{
    String title, dateCreated;
    int pages;
    boolean access;

    PaperDocument( String title, String dateCreated, int pages, boolean acess)
    {
        this.title = title;
        this.dateCreated = dateCreated;
        this.pages = pages;
        this.access = acess;
    }
}
