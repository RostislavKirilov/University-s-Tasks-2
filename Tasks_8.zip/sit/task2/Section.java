package com.company;

public class Section
{
    String Title;

    public static void findDocument1(String Title, PaperDocument[] arr)
    {
        for (int i = 0; i < arr.length; i++)
        {
            if(arr[i].title.equals(Title))
            {
                System.out.println("Document found!");
            }
        }
    }

    public static void findDocument2(int search, DiscStorage[] arr)
    {
        for (int i = 0; i < arr.length; i++)
        {
            if(arr[i].id == search)
            {
                System.out.println("Document found!");
            }
        }
    }
}
